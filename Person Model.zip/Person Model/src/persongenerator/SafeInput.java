package persongenerator;

public class SafeInput {
    public String getNonZeroLenString(String enter_first_name) {
        return enter_first_name;
    }

    public int getRangedInt() {
        return 0;
    }

    public boolean getYNConfirm() {
        return false;
    }
}
